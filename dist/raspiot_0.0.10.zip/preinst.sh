apt-get update
apt-get install python-dev libffi-dev libssl-dev
apt-get clean
apt-get autoremove

