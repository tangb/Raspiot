var testService = function($q, $rootScope) {
    var self = this;
};
    
var RaspIot = angular.module('RaspIot');
RaspIot.service('testService', ['$q', '$rootScope', testService]);

