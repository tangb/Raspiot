#!/bin/bash
touch /tmp/preinst.tmp

