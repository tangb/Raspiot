#!/bin/bash
touch /tmp/postuninst.tmp

