#!/bin/bash
#touch /tmp/postuninst.tmp
exit 130

