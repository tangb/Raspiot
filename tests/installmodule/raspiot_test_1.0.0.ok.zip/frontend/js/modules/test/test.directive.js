var testConfigDirective = function(testService) {

    var testController = function()
    {
        var self = this;
    };

    var testLink = function(scope, element, attrs, controller) {
        controller.init();
    };

    return {
        templateUrl: 'test.directive.html',
        replace: true,
        scope: true,
        controller: testController,
        controllerAs: 'testCtl',
        link: testLink
    };
};

var RaspIot = angular.module('RaspIot');
RaspIot.directive('testConfigDirective', ['testService', testConfigDirective])

