#!/bin/bash
touch /tmp/preuninst.tmp

