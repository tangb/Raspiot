#!/bin/bash
touch /tmp/postinst.tmp

